# Instagram-dio :camera:



Bem-vindo ao meu projeto feito durante minha participação no bootcamp de html da DIO. 



### Esse foi meu primeiro projeto na área de front-end e utilizei: 

- HTML5

- CSS3

  

  
  
 ![instagram pc](https://user-images.githubusercontent.com/55301440/124055959-3b4f3f00-d9fb-11eb-9399-89faefc4999e.png)


  
  ![instagram cel](https://user-images.githubusercontent.com/55301440/124055978-44d8a700-d9fb-11eb-8fb7-6ee65e854c4c.png)

  
  
  
  ​					Conforme meus conhecimentos forem avançando pretendo fazer atualizações no mesmo.

